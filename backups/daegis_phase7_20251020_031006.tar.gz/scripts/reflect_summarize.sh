#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/env python3 "$HOME/daegis/scripts/reflect_summarize.py"
