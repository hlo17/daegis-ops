#!/usr/bin/env bash
set -euo pipefail
exec "$HOME/daegis/tools/window_send.sh"
