#!/usr/bin/env python3
# (paste the Python script above here; ensure it's the same)
