#!/usr/bin/env python3
# (ファイル全文は上のコードブロックそのまま)
