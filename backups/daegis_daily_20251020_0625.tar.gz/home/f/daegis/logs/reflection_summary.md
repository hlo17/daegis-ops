# Halu Reflection Summary — 2025-10-19

_Generated at 2025-10-19T13:02:16Z (UTC), last 24h_

| Timestamp (UTC) | Level | Metric | Value | Threshold | Note |
|---|---|---:|---:|---:|---|
| 2025-10-19T09:58:16Z | warning | halu_last_heartbeat_age_seconds | 2793.5080013275146 | 180 | heartbeat stale (>3m) |
| 2025-10-19T09:59:17Z | warning | halu_last_heartbeat_age_seconds | 2853.511449575424 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:04:17Z | warning | halu_last_heartbeat_age_seconds | 3153.5286962985992 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:09:17Z | warning | halu_last_heartbeat_age_seconds | 3453.54554104805 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:14:17Z | warning | halu_last_heartbeat_age_seconds | 3753.5637249946594 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:23:33Z | critical | halu_up | 0 | 1 | exporter reports halu_up!=1 |
| 2025-10-19T10:27:03Z | info | boot | 1 | 0 | reflection loop alive |
| 2025-10-19T10:29:18Z | warning | halu_last_heartbeat_age_seconds | 250.72677969932556 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:29:38Z | info | heartbeat | 1 | 180 | heartbeat healthy |
| 2025-10-19T10:34:19Z | warning | halu_last_heartbeat_age_seconds | 295.6133334636688 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:39:19Z | warning | halu_last_heartbeat_age_seconds | 295.37439942359924 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:44:19Z | warning | halu_last_heartbeat_age_seconds | 295.3800835609436 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:49:19Z | critical | halu_up | 0 | 1 | exporter reports halu_up!=1 |
| 2025-10-19T10:49:19Z | warning | halu_last_heartbeat_age_seconds | 300.0944411754608 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:54:19Z | warning | halu_last_heartbeat_age_seconds | 299.93170404434204 | 180 | heartbeat stale (>3m) |
| 2025-10-19T10:59:19Z | warning | halu_last_heartbeat_age_seconds | 299.89645314216614 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:04:20Z | warning | halu_last_heartbeat_age_seconds | 299.6254653930664 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:09:20Z | warning | halu_last_heartbeat_age_seconds | 299.4235112667084 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:14:20Z | warning | halu_last_heartbeat_age_seconds | 299.259649515152 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:19:20Z | warning | halu_last_heartbeat_age_seconds | 299.0363562107086 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:24:21Z | warning | halu_last_heartbeat_age_seconds | 298.77388405799866 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:29:21Z | warning | halu_last_heartbeat_age_seconds | 298.6598062515259 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:34:21Z | warning | halu_last_heartbeat_age_seconds | 298.1004800796509 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:39:22Z | warning | halu_last_heartbeat_age_seconds | 297.85359287261963 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:44:22Z | warning | halu_last_heartbeat_age_seconds | 297.6185848712921 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:49:22Z | warning | halu_last_heartbeat_age_seconds | 297.3675537109375 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:54:22Z | warning | halu_last_heartbeat_age_seconds | 297.3651909828186 | 180 | heartbeat stale (>3m) |
| 2025-10-19T11:59:23Z | warning | halu_last_heartbeat_age_seconds | 297.10732221603394 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:04:23Z | warning | halu_last_heartbeat_age_seconds | 296.69618344306946 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:09:23Z | warning | halu_last_heartbeat_age_seconds | 296.6974172592163 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:14:23Z | warning | halu_last_heartbeat_age_seconds | 296.7065761089325 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:19:23Z | warning | halu_last_heartbeat_age_seconds | 296.6345646381378 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:24:23Z | warning | halu_last_heartbeat_age_seconds | 296.2769832611084 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:29:24Z | warning | halu_last_heartbeat_age_seconds | 296.2213776111603 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:34:24Z | warning | halu_last_heartbeat_age_seconds | 295.5675718784332 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:39:25Z | critical | halu_up | 0 | 1 | exporter reports halu_up!=1 |
| 2025-10-19T12:39:25Z | warning | halu_last_heartbeat_age_seconds | 300.3547468185425 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:44:25Z | warning | halu_last_heartbeat_age_seconds | 299.8242688179016 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:49:25Z | warning | halu_last_heartbeat_age_seconds | 299.755074262619 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:54:25Z | warning | halu_last_heartbeat_age_seconds | 299.6066691875458 | 180 | heartbeat stale (>3m) |
| 2025-10-19T12:59:25Z | warning | halu_last_heartbeat_age_seconds | 299.479129076004 | 180 | heartbeat stale (>3m) |
