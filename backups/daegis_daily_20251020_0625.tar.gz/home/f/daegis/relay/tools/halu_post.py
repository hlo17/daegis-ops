#!/usr/bin/env python3
import os, time, hmac, hashlib, urllib.request, urllib.parse, pathlib, sys
ENV=pathlib.Path("/home/f/daegis/relay/.env").read_text(encoding="utf-8").splitlines()
for ln in ENV:
    if "=" in ln and not ln.strip().startswith("#"):
        k,v=ln.split("=",1); os.environ.setdefault(k.strip(), v.strip())
team=os.environ["SLACK_TEAM_ID"]; sign=os.environ["SLACK_SIGNING_SECRET"]
text=" ".join(sys.argv[1:]).strip()
body=urllib.parse.urlencode({"token":"x","team_id":team,"text":text}).encode()
ts=str(int(time.time()))
bases=f"v0:{ts}:{body.decode()}".encode()
sig="v0="+hmac.new(sign.encode(), bases, hashlib.sha256).hexdigest()
req=urllib.request.Request("https://halu-roundtable.daegis-phronesis.com/slack/halu", data=body, method="POST",
    headers={"Content-Type":"application/x-www-form-urlencoded",
             "X-Slack-Request-Timestamp":ts, "X-Slack-Signature":sig})
with urllib.request.urlopen(req, timeout=8) as r:
    print(r.status, r.read().decode())
