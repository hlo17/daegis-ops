# Daegis Checklist (2025-09-24)
- Phase0(Mac): done
- Pi prod: T.B.D.
- KPI: Grafana/Prometheus/Alerts in place（Slack疎通テスト中）
- Mirror/Snapshot: workflows OK（lint微修正中）
- Pre-commit: ruff/black/yamllint
- Open issues: RAG source mix / Sora eval / S3 backup
