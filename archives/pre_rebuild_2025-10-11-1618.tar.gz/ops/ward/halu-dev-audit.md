# halu-dev backup audit (Mon Oct  6 15:38:39 JST 2025)
- Source: /Users/f/halu-dev.migrated.20251006-151256
- Dest  : /Users/f/daegis

## Files present only in backup (candidates to import)


## Top-level tree (backup)

