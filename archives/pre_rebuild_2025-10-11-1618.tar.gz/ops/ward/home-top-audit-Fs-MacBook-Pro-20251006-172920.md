# Home top-level audit (non-hidden only)

## bin — size: 12K
/Users/f/bin
├── ledgerdiff
├── mdappend
└── mdput

1 directory, 3 files

## ops — size: 4.0K
/Users/f/ops
└── tools
    └── deploy.sh

2 directories, 1 file

## work — size: 3.5M
/Users/f/work
└── daegis-ops
    ├── brief.md
    ├── docs
    ├── link_resolver.py
    ├── local.sh
    ├── ops
    ├── README.md
    ├── relay
    ├── roundtable
    └── tools

7 directories, 4 files

## venv — size: 37M
/Users/f/venv
└── poc
    ├── bin
    ├── include
    ├── lib
    └── pyvenv.cfg

5 directories, 1 file

