2025-09-30: Mac→Pi 経路/WSS/SSHトンネルでE2E可視化まで到達。Factory DAGの入口稼働を確認。
