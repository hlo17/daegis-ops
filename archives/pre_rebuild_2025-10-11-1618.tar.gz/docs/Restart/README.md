# Restart Folder (handoff)
- 目的: チャット/作業の引き継ぎ用テンポラリ置き場
- 扱い: 日次で中身を確認し、恒久情報は `registry/` / `ops/ward/` へ移す
- 期限: 7日以上放置しない（古い物は `docs/Archive/` へ移動）
