# Layout Standard
- docs/          … ドキュメント（Standards, Registry もここ）
- ops/           … 運用スクリプト・設定（bin/tools/docker/hosts…）
- ark/           … 生成物・バックアップ・ログブック
- projects/      … 実験/独立プロジェクト（消しても本体に影響なし）
- poc/           … 小さな検証
- venv/daegis    … Python 仮想環境（他の venv は作らない）
