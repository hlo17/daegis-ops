# Beacon
2025-10-12T19:00:01Z

- phase: unknown
- KPI:
  - canary: FAIL
  - hold_rate: 0.2241
  - e5xx: 394
  - p95_ms: 3005.72
  - adopt_block_last200: 4
- flags:
  - L5_VETO: absent
  - L105_COOLDOWN_UNTIL: present
- last events:
  - unknown · garden_gate.window · (no-topic)
  - unknown · garden_gate.window · (no-topic)
  - unknown · garden_gate.window · (no-topic)
  - unknown · garden_gate.window · (no-topic)
  - unknown · garden_gate.window · (no-topic)
  - unknown · garden_gate.window · (no-topic)
